class Tram:
    def __init__(self, tram_type, capacity, max_speed):
        self.tram_type = tram_type
        self.capacity = capacity
        self.max_speed = max_speed

    def transport_people(self):
        print(f"Tram {self.__class__.__name__} transported { Tram1.capacity } people")
    def display_info(self):
        print(f"Tram type: {Tram1.tram_type}\n Capacity: {Tram1.capacity} \n Max speed: {Tram1.max_speed}")

class Bus:
    def __init__(self, brand, capacity, color):
        self.brand = brand
        self.capacity = capacity
        self.color = color

    def transport_people(self):
        print(f"Bus {self.__class__.__name__} transported { Bus1.capacity } people")
    def display_info(self):
        print(f"Bus type: {Bus1.brand}\n Capacity: {Bus1.capacity} \n Color: {Bus1.color}")

class MercedesBenzBus:
    def __init__(self, brand, capacity, color, air_conditoning):
        self.brand = brand
        self.capacity = capacity
        self.color = color
        self.air_conditioning = air_conditoning

    def transport_people(self):
        print(f"Mercedes Benz {self.__class__.__name__} transported { Merc1.capacity } people")
    def display_info(self):
        print(f"Mercedes Benz type: {Merc1.brand}\n Capacity: {Merc1.capacity} \n Color: {Merc1.color} \n Air_conditioning: {Merc1.air_conditioning}")

Tram1 = Tram("Solaris", 40, 50)
Bus1 = Bus("Volvo", 34, 70)
Merc1 = MercedesBenzBus("Citaro", 60, "ładny", "działa")

Transport = [Tram1, Bus1, Merc1]

for obiekt in Transport:
    obiekt.transport_people()
    obiekt.display_info()
